/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package maquinacafe;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author lab5
 */
public class MaquinaCafe {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        



// --- 1. ENUMERAÇÕES (Definição de Estados) ---
enum StatusPagamento {
    APROVADO, PENDENTE, RECUSADO;
}

enum NivelEstoque {
    VERDE, AMARELO, VERMELHO;
}

// --- 2. INTERFACE (Contrato de Pagamento) ---
interface MetodoPagamento {
    boolean pagarPix(double valor);
    boolean pagarCartao(double valor);
}

// --- 3. ENTIDADES (Sabor e Estoque) ---
class Sabor {
    private final String nomeSabor;
    private int quantidadeAtual;
    private final int QUANTIDADE_MAXIMA = 30;

    public Sabor(String nome, int quantidadeInicial) {
        this.nomeSabor = nome;
        this.quantidadeAtual = Math.min(quantidadeInicial, QUANTIDADE_MAXIMA);
    }

    public String getNomeSabor() { return nomeSabor; }
    public int getQuantidadeAtual() { return quantidadeAtual; }

    public void reduzirQuantidade() {
        if (quantidadeAtual > 0) quantidadeAtual--;
    }

    public NivelEstoque verificarNivel() {
        if (quantidadeAtual == 0) return NivelEstoque.VERMELHO;
        if (quantidadeAtual <= 5) return NivelEstoque.AMARELO; // Regra: nível baixo acende luz amarela
        return NivelEstoque.VERDE;
    }
}

class Estoque {
    private final List<Sabor> sabores = new ArrayList<>();

    public Estoque() {
        // Regra: 6 sabores, 2 com nível baixo (luz amarela)
        sabores.add(new Sabor("Expresso", 30));
        sabores.add(new Sabor("Capuccino", 30));
        sabores.add(new Sabor("Macchiato", 3));  // AMARELO
        sabores.add(new Sabor("Latte", 4));      // AMARELO
        sabores.add(new Sabor("Mocha", 30));
        sabores.add(new Sabor("Carioca", 30));
    }

    public Sabor buscarSabor(String nome) {
        for (Sabor s : sabores) {
            if (s.getNomeSabor().equalsIgnoreCase(nome)) return s;
        }
        return null;
    }

    public void exibirPainelLuzes() {
        System.out.println("\n===== PAINEL DA MÁQUINA (LUZES) =====");
        for (Sabor s : sabores) {
            System.out.printf("Sabor: %-10s | Doses: %-2d | LUZ: [%s]\n", 
                s.getNomeSabor(), s.getQuantidadeAtual(), s.verificarNivel());
        }
        System.out.println("=====================================");
    }
}

// --- 4. LÓGICA DE PROCESSO (Baseado no seu BPMN) ---
class RealizarPedido implements MetodoPagamento {
    private final Estoque estoque;
    private final double PRECO = 5.00;

    public RealizarPedido(Estoque estoque) {
        this.estoque = estoque;
    }

    @Override
    public boolean pagarPix(double valor) {
        System.out.println("Processando Pix de R$" + valor + "...");
        return Math.random() > 0.2; // Simula 80% de sucesso
    }

    @Override
    public boolean pagarCartao(double valor) {
        System.out.println("Processando Cartão de R$" + valor + "...");
        return Math.random() > 0.1; // Simula 90% de sucesso
    }

    public void iniciarProcesso(String nomeSabor, int opcaoPgto) {
        Sabor sabor = estoque.buscarSabor(nomeSabor);

        // REGRA: Verificar Disponibilidade
        if (sabor == null) {
            System.out.println(">>> ERRO: Sabor não existe!");
            return;
        }
        if (sabor.getQuantidadeAtual() <= 0) {
            System.out.println(">>> ERRO: Estoque esgotado! (LUZ VERMELHA)");
            return;
        }

        // REGRA: Pagamento
        boolean sucesso = (opcaoPgto == 1) ? pagarPix(PRECO) : pagarCartao(PRECO);

        if (sucesso) {
            System.out.println(">>> PAGAMENTO AUTORIZADO!");
            sabor.reduzirQuantidade();
            System.out.println(">>> PREPARANDO " + sabor.getNomeSabor().toUpperCase() + "...");
            System.out.println(">>> COPO CHEIO! PODE RETIRAR.");
        } else {
            System.out.println(">>> ERRO: PAGAMENTO NÃO AUTORIZADO! Tente novamente.");
        }
    }
}

// --- 5. CLASSE PRINCIPAL (Ponto de entrada no NetBeans) ---
 {
  {
        try (Scanner leitor = new Scanner(System.in)) {
            Estoque estoque = new Estoque();
            RealizarPedido sistema;
            sistema = new RealizarPedido(estoque);
            
            System.out.println("BEM-VINDO À MÁQUINA DE CAFÉ JAVA");
            
            while (true) {
                estoque.exibirPainelLuzes();
                
                System.out.print("\nDigite o nome do sabor (ou 'sair'): ");
                String escolha = leitor.nextLine();
                
                if (escolha.equalsIgnoreCase("sair")) break;
                
                System.out.print("Forma de Pagamento (1-Pix | 2-Cartão): ");
                try {
                    int pgto = Integer.parseInt(leitor.nextLine());
                    sistema.iniciarProcesso(escolha, pgto);
                } catch (NumberFormatException e) {
                    System.out.println(">>> ERRO: Digite apenas números para o pagamento.");
                }
                
                System.out.println("\n--- Pressione ENTER para continuar ---");
                leitor.nextLine();
            }
            
            System.out.println("Máquina desligada.");
        }
    }

    }
    
    }
}

        

       
        


    
        // TODO code application logic here
    
    
